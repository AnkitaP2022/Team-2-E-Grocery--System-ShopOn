package com.grocery.service;

import com.grocery.dto.Purchase;
import com.grocery.dto.PurchaseResponse;

public interface CheckoutService {

    PurchaseResponse placeOrder(Purchase purchase);
}
